Vaktari archive fixture
